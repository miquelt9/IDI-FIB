#include "ExamGLWidget.h"

class MyGLWidget:public ExamGLWidget
{
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent=0) : ExamGLWidget(parent) {}
    ~MyGLWidget();

  protected:
    virtual void paintGL ();
    virtual void keyPressEvent(QKeyEvent* event);
    virtual void modelTransformCub (float escala, float angle);
    virtual void modelTransformPatricio ();
    virtual void projectTransform ();
    virtual void viewTransform ();

    virtual void iniEscena();

    float anglePat;
    float angleOffset;
    int mostrar; //Si ==0 mostra Cubs, ==1 mostra patricio

  private:
    int printOglError(const char file[], int line, const char func[]);

  public slots:
    void Cub1();
    void Cub2();
    void Cub3();
    void camPres();
    void camOrto();

  signals:
    void sendCub1();
    void sendCub2();
    void sendCub3();
    void sendCam1();
    void sendCam2();
};
